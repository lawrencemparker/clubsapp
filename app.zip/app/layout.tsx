import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Navbar from '../components/Navbar'; // Fixed path based on your structure
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'CrystalGrid',
  description: 'Organization Management Dashboard',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} bg-slate-950 text-white min-h-screen relative selection:bg-indigo-500/30 selection:text-indigo-200`}>
        <Navbar />
        <div className="pt-24">
          {children}
        </div>
      </body>
    </html>
  );
}