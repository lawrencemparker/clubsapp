'use client';

import { useState, useRef } from 'react';
import Link from 'next/link';

// --- TYPES ---
interface Comment {
  id: number;
  author: string;
  text: string;
  date: string;
}

interface Announcement {
  id: number;
  title: string;
  content: string;
  author: string;
  authorRole: string;
  date: string;
  category: string;
  isRead: boolean;
  status: 'published' | 'draft' | 'archived';
  attachments: string[]; 
  reactions: number;
  seenCount: number;
  comments: Comment[];
}

export default function AnnouncementsPage() {
  const [activeTab, setActiveTab] = useState<'published' | 'draft' | 'archived'>('published');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [expandedCommentId, setExpandedCommentId] = useState<number | null>(null);
  const [showToast, setShowToast] = useState(false);
  
  // --- MOCK DATA ---
  const [announcements, setAnnouncements] = useState<Announcement[]>([
    {
      id: 1,
      title: 'Annual Gala Location Change',
      content: 'Please note that due to unforeseen weather predictions, the Annual Gala has been moved to the Grand Ballroom at the Hilton. Parking validation will be provided.',
      author: 'Sarah Connor',
      authorRole: 'President',
      date: '2 hours ago',
      category: 'Urgent',
      isRead: false,
      status: 'published',
      attachments: ['Updated_Map.pdf'],
      reactions: 12,
      seenCount: 45,
      comments: [
        { id: 101, author: 'John Wick', text: 'Thanks for the update. Is the time the same?', date: '1 hour ago' }
      ]
    },
    {
      id: 2,
      title: 'Monthly Meeting Minutes - Jan',
      content: 'The minutes from our January meeting are now available. Please review the attached document before next week\'s session.',
      author: 'Tony Stark',
      authorRole: 'Secretary',
      date: '3 days ago',
      category: 'General',
      isRead: true,
      status: 'published',
      attachments: ['Jan_Minutes.docx', 'Financial_Report.xlsx'],
      reactions: 5,
      seenCount: 88,
      comments: []
    },
    {
      id: 3,
      title: 'Draft: Q1 Budget Proposal',
      content: 'Here is the draft for the upcoming budget vote. I need the treasurer to review the line items for catering.',
      author: 'You',
      authorRole: 'Admin',
      date: 'Last edited 10 mins ago',
      category: 'Financial',
      isRead: true,
      status: 'draft',
      attachments: [],
      reactions: 0,
      seenCount: 0,
      comments: []
    }
  ]);

  // --- FORM STATE ---
  const [formData, setFormData] = useState({
    title: '',
    category: 'General',
    content: '',
    notifyEmail: true,
    attachments: [] as File[]
  });
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- HANDLERS ---
  
  const handleMarkAsRead = (id: number) => {
    if (activeTab === 'published') {
      setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, isRead: true } : a));
    }
  };

  const handleReaction = (id: number) => {
    setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, reactions: a.reactions + 1 } : a));
  };

  const handleArchive = (id: number) => {
    if (confirm("Are you sure you want to archive this announcement?")) {
      setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, status: 'archived' } : a));
    }
  };

  const handlePostComment = () => {
    setShowToast(true);
    setExpandedCommentId(null);
    setTimeout(() => {
      setShowToast(false);
    }, 3000);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFormData({
        ...formData,
        attachments: [...formData.attachments, ...Array.from(e.target.files)]
      });
    }
  };

  const handleEditClick = (announcement: Announcement) => {
    setEditingId(announcement.id);
    setFormData({
      title: announcement.title,
      category: announcement.category,
      content: announcement.content,
      notifyEmail: false,
      attachments: [] 
    });
    setIsCreateModalOpen(true);
  };

  const handleModalClose = () => {
    setIsCreateModalOpen(false);
    setEditingId(null);
    setFormData({ title: '', category: 'General', content: '', notifyEmail: true, attachments: [] });
  };

  const handleCreateSubmit = (e: React.SyntheticEvent, isDraft: boolean = false) => {
    e.preventDefault();

    if (editingId) {
      setAnnouncements(prev => prev.map(a => {
        if (a.id === editingId) {
          return {
            ...a,
            title: formData.title,
            content: formData.content,
            category: formData.category,
            status: isDraft ? 'draft' : 'published',
            date: isDraft ? 'Edited just now' : 'Just now',
            attachments: [...a.attachments, ...formData.attachments.map(f => f.name)] 
          };
        }
        return a;
      }));
      
      if (!isDraft) alert("Announcement updated and published!");

    } else {
      const newPost: Announcement = {
        id: Date.now(),
        title: formData.title,
        content: formData.content,
        author: 'You',
        authorRole: 'Admin',
        date: 'Just now',
        category: formData.category,
        isRead: true,
        status: isDraft ? 'draft' : 'published',
        attachments: formData.attachments.map(f => f.name),
        reactions: 0,
        seenCount: 0,
        comments: []
      };
      setAnnouncements([newPost, ...announcements]);
      
      if (!isDraft && formData.notifyEmail) {
        alert("Email notification sent to all members.");
      }
    }

    handleModalClose();
  };

  const filteredAnnouncements = announcements.filter(a => a.status === activeTab);

  return (
    <main className="min-h-screen px-4 pb-20 pt-20 md:px-8 md:pt-24 lg:px-12 relative">
      
      {/* UPDATED TOAST POSITION:
        - top-24: Puts it below the header
        - left-1/2 -translate-x-1/2: Centers it horizontally
        - z-50: Ensures it floats above everything
      */}
      {showToast && (
        <div className="fixed top-24 left-1/2 transform -translate-x-1/2 z-50 animate-bounce">
          <div className="bg-emerald-500 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 font-bold border border-emerald-400">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Comment Posted Successfully!
          </div>
        </div>
      )}

      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="orb orb-1 !bg-orange-600/20" />
        <div className="orb orb-2 !bg-amber-600/20" />
      </div>

      <div className="w-full animate-fade-in max-w-5xl mx-auto">
        
        {/* HEADER */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <Link href="/dashboard" className="text-orange-300 text-sm hover:text-white mb-2 inline-flex items-center gap-1">
              &larr; Back to Dashboard
            </Link>
            <h1 className="text-4xl font-bold text-white tracking-tight">Announcements</h1>
            <p className="text-orange-100/60 mt-2">Organization news, updates, and alerts.</p>
          </div>
          <button 
            onClick={() => { setEditingId(null); setIsCreateModalOpen(true); }}
            className="glass-button bg-orange-500/20 hover:bg-orange-500/30 text-white px-6 py-3 rounded-xl font-bold border-orange-500/30 hover:border-orange-500/50 flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
            New Announcement
          </button>
        </div>

        {/* TABS */}
        <div className="flex gap-4 border-b border-white/10 mb-8 overflow-x-auto">
          {['published', 'draft', 'archived'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`pb-3 px-2 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${
                activeTab === tab 
                  ? 'border-orange-500 text-orange-400' 
                  : 'border-transparent text-white/40 hover:text-white hover:border-white/20'
              }`}
            >
              {tab === 'published' ? 'Active Feed' : tab === 'archived' ? 'History' : 'Drafts'}
            </button>
          ))}
        </div>

        {/* FEED */}
        <div className="space-y-6">
          {filteredAnnouncements.length === 0 && (
            <div className="glass-panel p-12 text-center text-white/30">
              No {activeTab} announcements found.
            </div>
          )}

          {filteredAnnouncements.map((post) => (
            <div 
              key={post.id} 
              className={`glass-panel p-6 md:p-8 transition-all relative ${!post.isRead && activeTab === 'published' ? 'border-orange-500/50 bg-orange-500/5 shadow-[0_0_30px_-5px_rgba(249,115,22,0.1)]' : ''}`}
              onClick={() => handleMarkAsRead(post.id)}
            >
              {/* Unread Indicator */}
              {!post.isRead && activeTab === 'published' && (
                <div className="absolute top-4 right-4 flex items-center gap-2">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-orange-500"></span>
                  </span>
                  <span className="text-xs font-bold text-orange-400">NEW</span>
                </div>
              )}

              {/* Header */}
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-orange-500 to-red-600 flex items-center justify-center text-white font-bold text-lg shrink-0">
                  {post.author.charAt(0)}
                </div>
                <div className="w-full">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-3">
                      <h3 className="text-xl font-bold text-white">{post.title}</h3>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide bg-white/10 text-white/60">
                        {post.category}
                      </span>
                    </div>
                    
                    <div className="flex gap-2">
                      {activeTab === 'draft' && (
                        <button 
                          onClick={(e) => { e.stopPropagation(); handleEditClick(post); }}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-200 hover:bg-indigo-500 hover:text-white transition-all shadow-sm font-bold text-xs"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                          Edit Draft
                        </button>
                      )}

                      {activeTab === 'published' && (
                        <button 
                          onClick={(e) => { e.stopPropagation(); handleArchive(post.id); }}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 border border-white/10 text-white/70 hover:text-white hover:border-orange-500/50 hover:bg-slate-700 transition-all shadow-sm group"
                          title="Archive Announcement"
                        >
                          <span className="text-xs font-bold hidden sm:inline group-hover:text-orange-200">Archive</span>
                          <svg className="w-4 h-4 group-hover:text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-sm text-white/50">
                    <span className="text-orange-200">{post.author}</span> • {post.authorRole} • {post.date}
                  </p>
                </div>
              </div>

              {/* Content */}
              <div className="pl-16">
                <p className="text-white/80 leading-relaxed mb-6 whitespace-pre-wrap">{post.content}</p>
                
                {post.attachments.length > 0 && (
                  <div className="flex flex-wrap gap-3 mb-6">
                    {post.attachments.map((file, i) => (
                      <div key={i} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-black/30 border border-white/10 hover:bg-white/5 cursor-pointer transition-colors group">
                        <svg className="w-4 h-4 text-blue-400 group-hover:text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                        <span className="text-sm text-blue-200 group-hover:text-white underline decoration-blue-500/30 underline-offset-2">{file}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Footer / Interactions (Only for Published) */}
                {activeTab !== 'draft' && (
                  <div className="flex items-center justify-between border-t border-white/10 pt-4">
                    <div className="flex gap-6">
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleReaction(post.id); }}
                        className="flex items-center gap-2 text-sm text-white/50 hover:text-orange-400 transition-colors"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" /></svg>
                        {post.reactions}
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); setExpandedCommentId(expandedCommentId === post.id ? null : post.id); }}
                        className="flex items-center gap-2 text-sm text-white/50 hover:text-blue-300 transition-colors"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" /></svg>
                        {post.comments.length} Comments
                      </button>
                    </div>
                    
                    <div className="flex items-center gap-2 text-xs text-white/30 font-mono">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                      Seen by {post.seenCount}
                    </div>
                  </div>
                )}

                {/* Comments Section */}
                {expandedCommentId === post.id && (
                  <div className="mt-4 pt-4 border-t border-white/5 bg-black/20 rounded-xl p-4 animate-fade-in">
                    {post.comments.length > 0 ? (
                      <div className="space-y-4 mb-4">
                        {post.comments.map(c => (
                          <div key={c.id} className="flex gap-3">
                            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold text-white/70">{c.author.charAt(0)}</div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-bold text-white">{c.author}</span>
                                <span className="text-xs text-white/30">{c.date}</span>
                              </div>
                              <p className="text-sm text-white/70">{c.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-white/30 italic mb-4">No comments yet.</p>
                    )}
                    <div className="flex gap-2">
                      <input type="text" placeholder="Write a comment..." className="glass-input text-sm py-2" />
                      <button 
                        onClick={handlePostComment} 
                        className="glass-button bg-white/10 hover:bg-white/20 px-4 text-sm font-bold"
                      >
                        Post
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* --- CREATE / EDIT ANNOUNCEMENT MODAL --- */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm" onClick={handleModalClose} />
          <div className="glass-panel w-full max-w-2xl p-8 relative z-50 animate-fade-in shadow-2xl border border-white/20 flex flex-col max-h-[90vh]">
            <h2 className="text-2xl font-bold text-white mb-6">
              {editingId ? 'Edit Announcement' : 'Create Announcement'}
            </h2>
            
            <form className="space-y-5 flex-1 overflow-y-auto pr-2">
              <div>
                <label className="block text-xs font-bold text-orange-200 uppercase tracking-wider mb-2">Title</label>
                <input 
                  required 
                  type="text" 
                  className="glass-input text-lg font-bold" 
                  placeholder="e.g., Upcoming Elections"
                  value={formData.title}
                  onChange={e => setFormData({...formData, title: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-orange-200 uppercase tracking-wider mb-2">Category</label>
                  <select 
                    className="glass-input bg-slate-900"
                    value={formData.category}
                    onChange={e => setFormData({...formData, category: e.target.value})}
                  >
                    <option value="General" className="bg-slate-800 text-white">General</option>
                    <option value="Urgent" className="bg-slate-800 text-white">Urgent</option>
                    <option value="Event" className="bg-slate-800 text-white">Event</option>
                    <option value="Financial" className="bg-slate-800 text-white">Financial</option>
                  </select>
                </div>
                
                <div className="flex items-end pb-2">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <div className={`w-12 h-6 rounded-full p-1 transition-colors ${formData.notifyEmail ? 'bg-green-500' : 'bg-slate-700'}`} onClick={() => setFormData({...formData, notifyEmail: !formData.notifyEmail})}>
                      <div className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${formData.notifyEmail ? 'translate-x-6' : 'translate-x-0'}`} />
                    </div>
                    <span className="text-sm text-white/70">Send Email Notification</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-orange-200 uppercase tracking-wider mb-2">Message</label>
                <div className="glass-input p-0 overflow-hidden flex flex-col min-h-[200px]">
                  <div className="flex items-center gap-2 p-2 border-b border-white/10 bg-white/5">
                    <button type="button" className="p-1 hover:bg-white/10 rounded"><b className="font-serif">B</b></button>
                    <button type="button" className="p-1 hover:bg-white/10 rounded"><i className="font-serif">I</i></button>
                    <button type="button" className="p-1 hover:bg-white/10 rounded"><u className="font-serif">U</u></button>
                    <div className="h-4 w-px bg-white/10 mx-2" />
                    <button type="button" className="p-1 hover:bg-white/10 rounded text-xs">List</button>
                    <button type="button" className="p-1 hover:bg-white/10 rounded text-xs">Link</button>
                  </div>
                  <textarea 
                    className="w-full flex-1 bg-transparent p-4 outline-none resize-none" 
                    placeholder="Type your announcement here..."
                    value={formData.content}
                    onChange={e => setFormData({...formData, content: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-orange-200 uppercase tracking-wider mb-2">Attachments</label>
                <div className="border-2 border-dashed border-white/20 rounded-xl p-6 text-center hover:bg-white/5 transition-colors cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                  <input type="file" ref={fileInputRef} multiple className="hidden" onChange={handleFileSelect} />
                  <svg className="w-8 h-8 text-white/40 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                  <p className="text-sm text-white/50">Click to attach documents</p>
                </div>
                {formData.attachments.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {formData.attachments.map((f, i) => (
                      <span key={i} className="text-xs bg-white/10 px-2 py-1 rounded text-white/80">{f.name}</span>
                    ))}
                  </div>
                )}
              </div>

              {/* FOOTER */}
              <div className="flex gap-4 pt-4 border-t border-white/10">
                <button 
                  type="button" 
                  onClick={handleModalClose}
                  className="px-6 py-3 rounded-xl font-medium text-white/60 hover:text-white hover:bg-white/5 transition-colors"
                >
                  Cancel
                </button>

                <button 
                  type="button" 
                  onClick={(e) => handleCreateSubmit(e, true)}
                  className="flex-1 py-3 rounded-xl font-bold text-white/50 hover:bg-white/5 transition-colors"
                >
                  {editingId ? 'Update Draft' : 'Save as Draft'}
                </button>
                
                <button 
                  type="button" 
                  onClick={(e) => handleCreateSubmit(e, false)}
                  className="flex-[2] glass-button bg-orange-500/20 hover:bg-orange-500/30 text-white font-bold"
                >
                  Publish Announcement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </main>
  );
}