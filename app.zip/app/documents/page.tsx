'use client';

import { useState, useRef } from 'react';
import Link from 'next/link';

// --- TYPES ---
interface DocFile {
  id: number;
  name: string;
  sizeDisplay: string;
  sizeBytes: number;
  type: string;
  uploader: string;
  date: string;
  category: 'doc' | 'photo';
  url: string; // Mock URL for opening files
}

// --- CONSTANTS ---
const STORAGE_LIMIT_BYTES = 1024 * 1024 * 1024; // 1 GB
const WARNING_THRESHOLD = 0.8; 
const PHOTO_EXTENSIONS = ['JPG', 'JPEG', 'PNG', 'GIF', 'SVG', 'WEBP', 'MP4', 'AI', 'PSD'];

export default function DocumentsPage() {
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Search Term State
  const [searchTerm, setSearchTerm] = useState('');
  
  // --- MOCK DATA ---
  const [files, setFiles] = useState<DocFile[]>([
    { 
      id: 1, name: '2025_Gala_Footage_Raw.mp4', sizeDisplay: '850 MB', sizeBytes: 850 * 1024 * 1024, 
      type: 'MP4', uploader: 'Sarah Connor', date: '25 mins ago', category: 'photo', url: '#' 
    },
    { 
      id: 2, name: 'Sponsorship_Package.pdf', sizeDisplay: '45 MB', sizeBytes: 45 * 1024 * 1024, 
      type: 'PDF', uploader: 'Tony Stark', date: '1 hour ago', category: 'doc', url: '#' 
    },
    { 
      id: 3, name: 'Event_Logo_Vector.ai', sizeDisplay: '12 MB', sizeBytes: 12 * 1024 * 1024, 
      type: 'AI', uploader: 'John Wick', date: 'Yesterday', category: 'photo', url: '#' 
    },
    { 
      id: 4, name: 'Budget_Q1_2025.xlsx', sizeDisplay: '128 KB', sizeBytes: 128 * 1024, 
      type: 'XLSX', uploader: 'Pepper Potts', date: '2 days ago', category: 'doc', url: '#' 
    },
    { 
      id: 5, name: 'Team_Headshot_01.jpg', sizeDisplay: '4.2 MB', sizeBytes: 4.2 * 1024 * 1024, 
      type: 'JPG', uploader: 'Peter Parker', date: '3 days ago', category: 'photo', url: '#' 
    },
  ]);

  const [uploadQueue, setUploadQueue] = useState<File[]>([]);

  // --- FILTER LOGIC ---
  const filteredFiles = files.filter(file => {
    const term = searchTerm.toLowerCase();
    return (
      file.name.toLowerCase().includes(term) || 
      file.uploader.toLowerCase().includes(term)
    );
  });

  const docFiles = filteredFiles.filter(f => f.category === 'doc');
  const photoFiles = filteredFiles.filter(f => f.category === 'photo');

  // --- STORAGE CALCULATIONS ---
  const totalBytesUsed = files.reduce((acc, file) => acc + file.sizeBytes, 0);
  const usagePercentage = Math.min((totalBytesUsed / STORAGE_LIMIT_BYTES) * 100, 100);
  const totalGBUsed = (totalBytesUsed / (1024 * 1024 * 1024)).toFixed(2);
  const isNearLimit = usagePercentage / 100 >= WARNING_THRESHOLD;

  // --- HANDLERS ---
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files);
      setUploadQueue(prev => [...prev, ...newFiles]);
    }
  };

  const handleUploadConfirm = () => {
    const newFiles: DocFile[] = uploadQueue.map((file, i) => {
      const ext = file.name.split('.').pop()?.toUpperCase() || 'FILE';
      const isPhoto = PHOTO_EXTENSIONS.includes(ext);
      
      return {
        id: Date.now() + i,
        name: file.name,
        sizeDisplay: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
        sizeBytes: file.size,
        type: ext,
        uploader: 'You',
        date: 'Just now',
        category: isPhoto ? 'photo' : 'doc',
        url: '#'
      };
    });
    
    const newTotalBytes = totalBytesUsed + newFiles.reduce((acc, f) => acc + f.sizeBytes, 0);
    if (newTotalBytes > STORAGE_LIMIT_BYTES) {
      alert("Upload failed: Not enough storage space. Please upgrade your plan.");
      return;
    }
    
    setFiles([...newFiles, ...files]);
    setUploadQueue([]);
    setIsUploadModalOpen(false);
  };

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this file?')) {
      setFiles(files.filter(f => f.id !== id));
    }
  };

  const handleOpenFile = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    // Updated padding-top to pt-16 md:pt-20 to move content higher up, matching other pages.
    <main className="min-h-screen px-4 pb-20 pt-16 md:px-8 md:pt-20 lg:px-12 relative">
      
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="orb orb-1 !bg-teal-600/30" />
        <div className="orb orb-2 !bg-cyan-600/30" />
      </div>

      <div className="w-full animate-fade-in">
        
        {/* Header & Actions */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div className="shrink-0">
            <Link href="/dashboard" className="text-teal-300 text-sm hover:text-white mb-2 inline-flex items-center gap-1">
              &larr; Back to Dashboard
            </Link>
            <h1 className="text-4xl font-bold text-white tracking-tight">Document Repository</h1>
            <p className="text-teal-100/60 mt-2">Centralized storage for organization assets.</p>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto items-center">
            
            {/* Search Bar - Fixed Width 650px */}
            <div className="relative w-full md:w-[650px] shrink-0">
              <input
                type="text"
                placeholder="Search files or uploader..."
                className="glass-input !pl-14 pr-4 py-3 w-full transition-all text-white placeholder-white/40 outline-none focus:ring-2 focus:ring-teal-500/50"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <svg className="w-5 h-5 text-teal-200 absolute left-4 top-1/2 transform -translate-y-1/2 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>

            <button onClick={() => setIsUploadModalOpen(true)} className="glass-button bg-teal-500/20 hover:bg-teal-500/30 text-white px-6 py-3 rounded-xl font-bold border-teal-500/30 hover:border-teal-500/50 flex items-center justify-center gap-2 whitespace-nowrap w-full md:w-auto shrink-0">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
              Upload Files
            </button>
          </div>
        </div>

        {/* Storage Meter */}
        <div className="glass-panel p-6 mb-8 border-t-4 border-teal-500">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="text-2xl font-bold text-white mb-1">Storage Usage</h3>
              <p className="text-lg text-white/70">
                You are using <span className="text-white font-bold text-xl">{totalGBUsed} GB</span> of your <span className="text-white font-bold text-xl">1 GB</span> limit.
              </p>
            </div>
            {isNearLimit && (
              <button className="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white text-base font-bold rounded-lg shadow-lg shadow-orange-500/20 animate-pulse transition-all transform hover:scale-105">
                Upgrade to Pro Plan (10 GB) &rarr;
              </button>
            )}
          </div>
          <div className="w-full h-6 bg-slate-800 rounded-full overflow-hidden border border-white/10">
            <div 
              className={`h-full transition-all duration-1000 ease-out ${
                usagePercentage > 90 ? 'bg-red-500' : 
                usagePercentage > 75 ? 'bg-amber-500' : 'bg-teal-500'
              }`}
              style={{ width: `${usagePercentage}%` }}
            />
          </div>
          <div className="flex justify-between mt-3 text-sm font-bold text-white/50 tracking-wide">
            <span>0 GB</span>
            <span>0.5 GB</span>
            <span>1 GB Limit</span>
          </div>
        </div>

        {/* --- DUAL GALLERIES --- */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* COLUMN 1: DOCUMENTS (List View) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <svg className="w-5 h-5 text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                Documents
              </h3>
              <span className="text-xs font-bold text-white/40 uppercase tracking-wider">{docFiles.length} FILES</span>
            </div>
            
            <div className="glass-panel overflow-hidden">
              <div className="max-h-[600px] overflow-y-auto">
                {docFiles.length === 0 ? (
                  <div className="p-8 text-center text-white/30 text-sm">No documents found.</div>
                ) : (
                  <table className="w-full text-left">
                    <thead className="bg-white/5 sticky top-0 backdrop-blur-md">
                      <tr className="text-xs font-bold text-white/50 uppercase tracking-wider">
                        <th className="p-4">Name</th>
                        <th className="p-4 text-right">Size</th>
                        <th className="p-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-sm">
                      {docFiles.map(file => (
                        <tr 
                          key={file.id} 
                          onClick={() => handleOpenFile(file.url)}
                          className="hover:bg-white/5 transition-colors group cursor-pointer"
                        >
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded bg-blue-500/20 flex items-center justify-center text-blue-200 text-xs font-bold shrink-0">
                                {file.type}
                              </div>
                              <div className="truncate max-w-[200px] sm:max-w-xs">
                                <div className="text-white font-medium truncate group-hover:text-blue-200 transition-colors">{file.name}</div>
                                <div className="text-xs text-white/40">{file.uploader} • {file.date}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-right text-white/60 whitespace-nowrap">{file.sizeDisplay}</td>
                          <td className="p-4 text-right">
                            <button 
                              onClick={(e) => handleDelete(e, file.id)} 
                              className="text-white/20 hover:text-red-400 transition-colors p-2 hover:bg-red-500/10 rounded-lg"
                              title="Delete Document"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>

          {/* COLUMN 2: PHOTOS & MEDIA (Grid View) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <svg className="w-5 h-5 text-purple-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                Photos & Media
              </h3>
              <span className="text-xs font-bold text-white/40 uppercase tracking-wider">{photoFiles.length} FILES</span>
            </div>

            {photoFiles.length === 0 ? (
              <div className="glass-panel p-12 text-center text-white/30 text-sm">No photos or media found.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {photoFiles.map(file => (
                  <div 
                    key={file.id} 
                    className="glass-panel p-3 group hover:bg-white/10 transition-colors relative flex flex-col h-full"
                  >
                    {/* Thumbnail */}
                    <div 
                      className="aspect-square rounded-lg bg-black/40 border border-white/5 mb-3 flex items-center justify-center overflow-hidden cursor-pointer"
                      onClick={() => handleOpenFile(file.url)}
                    >
                      <div className="text-purple-300 font-bold text-2xl opacity-30 group-hover:scale-110 transition-transform duration-300">
                        {file.type}
                      </div>
                    </div>
                    
                    {/* Footer */}
                    <div className="mt-auto">
                      <div 
                        className="truncate text-sm font-medium text-white cursor-pointer hover:text-blue-300 transition-colors mb-2"
                        onClick={() => handleOpenFile(file.url)}
                      >
                        {file.name}
                      </div>
                      
                      <div className="flex justify-between items-center border-t border-white/10 pt-2 mt-1">
                        <div className="flex flex-col">
                          <span className="text-[10px] text-white/40 font-bold uppercase">{file.sizeDisplay}</span>
                          <span className="text-[9px] text-white/30">{file.date}</span>
                        </div>
                        
                        <button 
                          onClick={(e) => handleDelete(e, file.id)}
                          className="w-8 h-8 flex items-center justify-center rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition-all"
                          title="Delete File"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* --- UPLOAD MODAL --- */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsUploadModalOpen(false)} />
          <div className="glass-panel w-full max-w-4xl h-[550px] relative z-50 flex overflow-hidden">
            <div className="w-1/2 p-8 border-r border-white/10 flex flex-col justify-center items-center text-center bg-white/5">
              <input type="file" multiple className="hidden" ref={fileInputRef} onChange={handleFileSelect} />
              <div className="w-20 h-20 rounded-2xl bg-teal-500/20 flex items-center justify-center mb-6">
                <svg className="w-10 h-10 text-teal-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Drag and drop file</h3>
              <p className="text-white/40 text-sm mb-6">or</p>
              <button onClick={() => fileInputRef.current?.click()} className="glass-button bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-xl font-bold w-full max-w-[200px]">Browse</button>
              <div className="mt-8 text-xs text-white/30 space-y-1">
                <p>Infrastructure Limits:</p>
                <p>Max file size: <span className="text-teal-400">50 MB</span></p>
                <p>Max batch size: <span className="text-teal-400">10 files</span></p>
              </div>
            </div>
            
            <div className="w-1/2 p-8 flex flex-col bg-slate-900/90">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-white">Files to Upload</h3>
                <span className="text-xs text-white/50">{uploadQueue.length} files selected</span>
              </div>
              <div className="flex-1 overflow-y-auto space-y-3">
                {uploadQueue.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-white/30 text-sm">No files selected</div>
                ) : (
                  uploadQueue.map((f, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5">
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div className="w-8 h-8 rounded bg-blue-500/20 flex items-center justify-center text-blue-300 text-xs font-bold">{f.name.split('.').pop()?.toUpperCase()}</div>
                        <div className="truncate">
                          <p className="text-sm text-white truncate max-w-[150px]">{f.name}</p>
                          <p className="text-xs text-white/40">{(f.size / 1024).toFixed(1)} KB</p>
                        </div>
                      </div>
                      <button onClick={() => setUploadQueue(uploadQueue.filter((_, idx) => idx !== i))} className="text-white/40 hover:text-white">&times;</button>
                    </div>
                  ))
                )}
              </div>
              <div className="mt-6 pt-6 border-t border-white/10 flex justify-end gap-3">
                <button onClick={() => setIsUploadModalOpen(false)} className="px-4 py-2 text-white/60 hover:text-white">Cancel</button>
                <button onClick={handleUploadConfirm} disabled={uploadQueue.length === 0} className="glass-button bg-teal-500/20 hover:bg-teal-500/30 text-white px-6 py-2 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed">Upload All</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}