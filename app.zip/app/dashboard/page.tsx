'use client';

import { useState, useRef, useMemo } from 'react';
import Link from 'next/link';

// --- TYPES ---
interface Member {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  position: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  duesPaid: boolean;
  lastActive: string;
  accountStatus: 'Active' | 'Invited' | 'Suspended'; 
  permissions: {
    canCreateEvents: boolean;
    canAddMembers: boolean;
    canUploadDocuments: boolean;
    canCreateAnnouncements: boolean;
  };
}

// --- UTILITIES FOR 3D CHART ---
const darkenColor = (hex: string, percent: number) => {
  let num = parseInt(hex.replace("#", ""), 16),
    amt = Math.round(2.55 * percent),
    R = (num >> 16) - amt,
    B = ((num >> 8) & 0x00ff) - amt,
    G = (num & 0x0000ff) - amt;
  return (
    "#" +
    (
      0x1000000 +
      (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
      (B < 255 ? (B < 1 ? 0 : B) : 255) * 0x100 +
      (G < 255 ? (G < 1 ? 0 : G) : 255)
    )
      .toString(16)
      .slice(1)
  );
};

// --- 3D PIE CHART COMPONENT ---
const PieChart3D = ({ 
  data, 
  radius = 110, // Restored slightly larger size for h-full
  depth = 30, 
  hole = 0 
}: { data: { label: string; value: number; color: string }[]; radius?: number; depth?: number; hole?: number }) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const processedData = useMemo(() => {
    const total = data.reduce((acc, item) => acc + item.value, 0);
    let cumulativePercent = 0;

    return data.map((slice, index) => {
      const startPercent = cumulativePercent;
      const slicePercent = total === 0 ? 0 : slice.value / total;
      const endPercent = startPercent + slicePercent;
      cumulativePercent = endPercent;

      return {
        ...slice,
        id: index,
        startPercent,
        endPercent,
        percentLabel: (slicePercent * 100).toFixed(0) + "%",
      };
    });
  }, [data]);

  const slices = processedData.map((slice) => {
    const { startPercent, endPercent, color } = slice;
    const startX = Math.cos(2 * Math.PI * (startPercent - 0.25));
    const startY = Math.sin(2 * Math.PI * (startPercent - 0.25));
    const endX = Math.cos(2 * Math.PI * (endPercent - 0.25));
    const endY = Math.sin(2 * Math.PI * (endPercent - 0.25));
    const largeArcFlag = endPercent - startPercent > 0.5 ? 1 : 0;

    const pathData = [
      `M ${startX * hole} ${startY * hole}`,
      `L ${startX * radius} ${startY * radius}`,
      `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX * radius} ${endY * radius}`,
      `L ${endX * hole} ${endY * hole}`,
      `A ${hole} ${hole} 0 ${largeArcFlag} 0 ${startX * hole} ${startY * hole}`,
    ].join(" ");

    const sidePathData = [
      `M ${startX * radius} ${startY * radius}`,
      `L ${startX * radius} ${startY * radius + depth}`,
      `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX * radius} ${endY * radius + depth}`,
      `L ${endX * radius} ${endY * radius}`,
      `A ${radius} ${radius} 0 ${largeArcFlag} 0 ${startX * radius} ${startY * radius}`,
    ].join(" ");

    const midPercent = (startPercent + endPercent) / 2;
    const midX = Math.cos(2 * Math.PI * (midPercent - 0.25)) * radius;
    const midY = Math.sin(2 * Math.PI * (midPercent - 0.25)) * radius;
    const dist = radius + 25; 
    const labelX = Math.cos(2 * Math.PI * (midPercent - 0.25)) * dist;
    const labelY = Math.sin(2 * Math.PI * (midPercent - 0.25)) * dist;
    const isLeft = midPercent > 0.5; 
    const textAnchor = isLeft ? "end" : "start";
    const textX = isLeft ? labelX - 15 : labelX + 15;

    return {
      ...slice,
      pathData,
      sidePathData,
      darkColor: darkenColor(color, 20),
      midX,
      midY,
      labelX,
      labelY,
      textX,
      textAnchor,
    };
  });

  return (
    <div className="w-full flex flex-col items-center justify-center font-sans h-full">
      <div className="relative w-full h-full min-h-[250px] flex items-center justify-center"> 
        <svg viewBox="-300 -200 600 400" className="w-full h-full overflow-visible" style={{ transform: "rotateX(25deg)" }}>
          <defs>
            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="8" stdDeviation="4" floodOpacity="0.4" />
            </filter>
          </defs>
          <g>
            {slices.map((slice, i) => (
              <g key={slice.id} onMouseEnter={() => setHoveredIndex(i)} onMouseLeave={() => setHoveredIndex(null)} style={{ transform: hoveredIndex === i ? `scale(1.03)` : "scale(1)", transition: "transform 0.3s ease", transformOrigin: "center", cursor: "pointer" }}>
                <path d={slice.sidePathData} fill={slice.darkColor} />
                <path d={slice.pathData} fill={slice.color} filter="url(#shadow)" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />
              </g>
            ))}
          </g>
          <g>
            {slices.map((slice) => (
              <g key={`label-${slice.id}`} className="pointer-events-none">
                <polyline points={`${slice.midX},${slice.midY} ${slice.labelX},${slice.labelY} ${slice.textX},${slice.labelY}`} fill="none" stroke="#e2e8f0" strokeWidth="2" strokeOpacity="0.8" />
                <text x={slice.textX} y={slice.labelY} dy="-0.4em" textAnchor={slice.textAnchor} className="font-bold fill-white drop-shadow-md" style={{ fontSize: '16px', fontWeight: 800 }}>
                  {slice.label} ({slice.value})
                </text>
                <text x={slice.textX} y={slice.labelY} dy="1.1em" textAnchor={slice.textAnchor} className="fill-slate-300 font-medium" style={{ fontSize: '12px' }}>
                  {slice.percentLabel}
                </text>
              </g>
            ))}
          </g>
        </svg>
      </div>
    </div>
  );
};

// --- HELPER UTILS ---
const downloadCSV = (data: any[], filename: string) => { 
  if (!data.length) return alert("No data to export.");
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','), 
    ...data.map(row => headers.map(fieldName => {
      const value = row[fieldName]?.toString() || '';
      return value.match(/[, \n"]/) ? `"${value.replace(/"/g, '""')}"` : value;
    }).join(','))
  ].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export default function DashboardPage() {
  // --- ORG STATE ---
  const orgName = "Kappa Alpha Psi - Beta XI Chapter";
  const [orgLogo, setOrgLogo] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const csvInputRef = useRef<HTMLInputElement>(null); 
  
  // --- MEMBER STATE ---
  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [editingMemberId, setEditingMemberId] = useState<number | null>(null);
  const [isManageAdminsOpen, setIsManageAdminsOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  
  const [importPreviewData, setImportPreviewData] = useState<Member[]>([]);
  const [adminSearchTerm, setAdminSearchTerm] = useState('');
  const [isAddingAdmin, setIsAddingAdmin] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [activeEventCount, setActiveEventCount] = useState(3);

  // --- INITIAL DATA ---
  const [members, setMembers] = useState<Member[]>([
    {
      id: 1, firstName: 'Sarah', lastName: 'Connor', email: 'sarah@example.com', phone: '555-0123',
      position: 'President', address: '123 Tech Blvd', city: 'Los Angeles', state: 'CA', zip: '90001', 
      duesPaid: true, lastActive: '2 mins ago', accountStatus: 'Active',
      permissions: { canCreateEvents: true, canAddMembers: true, canUploadDocuments: true, canCreateAnnouncements: true }
    },
    {
      id: 2, firstName: 'John', lastName: 'Wick', email: 'john@example.com', phone: '555-0999',
      position: 'Security Head', address: 'Continental Hotel', city: 'New York', state: 'NY', zip: '10001', 
      duesPaid: false, lastActive: '1 hour ago', accountStatus: 'Active',
      permissions: { canCreateEvents: false, canAddMembers: false, canUploadDocuments: false, canCreateAnnouncements: false }
    },
    {
      id: 3, firstName: 'Bruce', lastName: 'Wayne', email: 'bruce@wayne.com', phone: '555-4000',
      position: 'Benefactor', address: '1007 Mountain Dr', city: 'Gotham', state: 'NJ', zip: '07001',
      duesPaid: true, lastActive: '5 hours ago', accountStatus: 'Active',
      permissions: { canCreateEvents: false, canAddMembers: false, canUploadDocuments: false, canCreateAnnouncements: false }
    },
    {
      id: 4, firstName: 'Clark', lastName: 'Kent', email: 'kal@el.com', phone: '555-5000',
      position: 'Reporter', address: '344 Clinton St', city: 'Metropolis', state: 'NY', zip: '10001',
      duesPaid: false, lastActive: 'Invite Sent', accountStatus: 'Invited',
      permissions: { canCreateEvents: false, canAddMembers: false, canUploadDocuments: false, canCreateAnnouncements: false }
    }
  ]);

  const [currentUser, setCurrentUser] = useState<Member>(members[0]);
  const isAdministrator = (m: Member) => Object.values(m.permissions).some(Boolean);
  const isAdmin = isAdministrator(currentUser);

  const [memberFormData, setMemberFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', position: '', 
    address: '', city: '', state: '', zip: '', duesPaid: false,
    canCreateEvents: false, canAddMembers: false, canUploadDocuments: false, canCreateAnnouncements: false
  });

  const [eventFormData, setEventFormData] = useState({
    title: '', date: '', displayDate: '', time: '', location: '', category: 'Social'
  });

  // --- HANDLERS ---
  const handleLogoUpdate = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) setOrgLogo(URL.createObjectURL(e.target.files[0]));
  };

  const handleOpenMemberCreate = () => {
    setEditingMemberId(null);
    setMemberFormData({
      firstName: '', lastName: '', email: '', phone: '', position: '', address: '', city: '', state: '', zip: '', duesPaid: false,
      canCreateEvents: false, canAddMembers: false, canUploadDocuments: false, canCreateAnnouncements: false
    });
    setIsMemberModalOpen(true);
  };

  const handleOpenMemberEdit = (member: Member) => {
    setEditingMemberId(member.id);
    setMemberFormData({
      firstName: member.firstName, lastName: member.lastName, email: member.email, phone: member.phone,
      position: member.position, address: member.address, city: member.city, state: member.state, zip: member.zip, duesPaid: member.duesPaid,
      canCreateEvents: member.permissions.canCreateEvents,
      canAddMembers: member.permissions.canAddMembers,
      canUploadDocuments: member.permissions.canUploadDocuments,
      canCreateAnnouncements: member.permissions.canCreateAnnouncements
    });
    setIsMemberModalOpen(true);
  };

  const handleDeleteMember = () => {
    if (!editingMemberId) return;
    if (confirm("Are you sure you want to delete this member?")) {
      setMembers(members.filter(m => m.id !== editingMemberId));
      setIsMemberModalOpen(false);
    }
  };

  const handleMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const permissions = {
      canCreateEvents: memberFormData.canCreateEvents,
      canAddMembers: memberFormData.canAddMembers,
      canUploadDocuments: memberFormData.canUploadDocuments,
      canCreateAnnouncements: memberFormData.canCreateAnnouncements
    };
    if (editingMemberId) {
      setMembers(members.map(m => m.id === editingMemberId ? { ...m, ...memberFormData, permissions } : m));
    } else {
      setMembers([{ 
        id: Date.now(), 
        ...memberFormData, 
        lastActive: 'Invite Sent', 
        accountStatus: 'Invited', 
        permissions 
      }, ...members]);
      alert(`Invitation email sent to ${memberFormData.email}.`);
    }
    setIsMemberModalOpen(false);
  };

  const handleResendInvite = (e: React.MouseEvent, member: Member) => {
    e.stopPropagation();
    alert(`Invitation link re-sent to ${member.email}`);
  };

  // --- ADMIN MANAGEMENT HANDLERS ---
  const currentAdmins = members.filter(isAdministrator);
  const potentialAdmins = members.filter(m => !isAdministrator(m) && (
    m.firstName.toLowerCase().includes(adminSearchTerm.toLowerCase()) || 
    m.lastName.toLowerCase().includes(adminSearchTerm.toLowerCase())
  ));

  const handlePromoteToAdmin = (id: number) => {
    setMembers(members.map(m => m.id === id ? { ...m, permissions: { canCreateEvents: true, canAddMembers: true, canUploadDocuments: true, canCreateAnnouncements: true } } : m));
    setIsAddingAdmin(false);
    setAdminSearchTerm('');
  };

  const handleRevokeAdmin = (id: number) => {
    if(confirm("Revoke admin privileges?")) {
      setMembers(members.map(m => m.id === id ? { ...m, permissions: { canCreateEvents: false, canAddMembers: false, canUploadDocuments: false, canCreateAnnouncements: false } } : m));
    }
  };

  const handleExportAllMembers = () => {
    const data = members.map(m => ({ "First Name": m.firstName, "Last Name": m.lastName, "Email": m.email }));
    downloadCSV(data, `full_roster.csv`);
  };

  const handleExportUnpaidMembers = () => {
    const data = members.filter(m => !m.duesPaid).map(m => ({ "First Name": m.firstName, "Last Name": m.lastName, "Email": m.email, "Status": "Unpaid" }));
    downloadCSV(data, `unpaid_members.csv`);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const csvText = event.target?.result as string;
      const lines = csvText.split('\n');
      const parsedMembers: Member[] = [];
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const cols = line.split(',');
        if (cols.length < 3) continue;
        parsedMembers.push({
          id: Date.now() + i, 
          firstName: cols[0] || 'Unknown', lastName: cols[1] || '', email: cols[2] || '', phone: cols[3] || '', position: cols[4] || 'Member',
          address: '', city: '', state: '', zip: '', duesPaid: false, lastActive: 'Never', accountStatus: 'Invited',
          permissions: { canCreateEvents: false, canAddMembers: false, canUploadDocuments: false, canCreateAnnouncements: false }
        });
      }
      setImportPreviewData(parsedMembers);
      setIsImportModalOpen(true);
    };
    reader.readAsText(file);
    if (csvInputRef.current) csvInputRef.current.value = '';
  };

  const confirmImport = () => {
    setMembers([...importPreviewData, ...members]);
    setIsImportModalOpen(false);
    setImportPreviewData([]);
    alert(`Successfully imported ${importPreviewData.length} members!`);
  };

  const downloadSampleCSV = () => {
    const csvContent = "FirstName,LastName,Email,Phone,Position\nAlice,Wonderland,alice@test.com,555-0000,Member";
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample_members.csv';
    a.click();
  };

  const handleEventSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEventModalOpen(false);
    alert("Event Created Successfully!");
  };

  // --- CALCULATIONS ---
  const paidMembers = members.filter(m => m.duesPaid).length;
  const pendingDues = members.length - paidMembers;
  const chartData = [
    { label: "Paid", value: paidMembers, color: "#ef4444" },
    { label: "Pending", value: pendingDues, color: "#94a3b8" }
  ];

  return (
    <main className="min-h-screen p-4 md:p-8 lg:p-12 pb-20 relative">
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="orb orb-1" />
        <div className="orb orb-2" />
        <div className="orb orb-3" />
      </div>

      <div className="w-full animate-fade-in">
        
        {/* HEADER SECTION */}
        <div className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-6">
            <div className="relative group">
              <input type="file" ref={logoInputRef} accept="image/*" className="hidden" onChange={handleLogoUpdate} />
              <div 
                onClick={() => logoInputRef.current?.click()}
                className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-600 to-red-900 border border-white/20 flex items-center justify-center shadow-lg shadow-red-900/50 shrink-0 overflow-hidden cursor-pointer relative"
              >
                 {orgLogo ? <img src={orgLogo} alt="Organization Logo" className="w-full h-full object-cover" /> : <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zm0 9l2.5-1.25L12 8.5l-2.5 1.25L12 11zm0 2.5l-5-2.5-5 2.5L12 22l10-8.5-5-2.5-5 2.5z"/></svg>}
              </div>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-white tracking-tight leading-tight">
                {orgName} <span className="text-blue-400">Dashboard</span>
              </h1>
              <p className="text-blue-100/60 mt-2 text-lg">
                Welcome back, {currentUser.firstName}.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-white/5 p-2 rounded-xl border border-white/10">
            <span className="text-xs text-white/50 uppercase font-bold px-2">View As:</span>
            <button onClick={() => setCurrentUser(members[0])} className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${currentUser.id === 1 ? 'bg-blue-500 text-white' : 'text-white/50 hover:text-white'}`}>Admin</button>
            <button onClick={() => setCurrentUser(members[1])} className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${currentUser.id === 2 ? 'bg-blue-500 text-white' : 'text-white/50 hover:text-white'}`}>Member</button>
          </div>
        </div>

        {/* --- MAIN DASHBOARD GRID --- */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* COL 1: RECENT MEMBERS (MATCHES ROW HEIGHT) */}
          <div className="glass-panel p-6 flex flex-col h-full">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                Recent Members
              </h3>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-2">
              {members.map((member) => (
                <div 
                  key={member.id} 
                  onClick={() => isAdmin ? handleOpenMemberEdit(member) : null} 
                  className={`flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5 transition-colors group ${isAdmin ? 'hover:bg-white/10 cursor-pointer' : ''}`}
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0 ${member.accountStatus === 'Invited' ? 'bg-slate-700 border border-dashed border-white/30' : 'bg-gradient-to-tr from-indigo-500 to-purple-500'}`}>
                      {member.firstName.charAt(0)}
                    </div>
                    <div className="truncate">
                      <div className="flex items-center gap-2">
                        <p className={`text-base font-bold truncate transition-colors ${member.accountStatus === 'Invited' ? 'text-white/60 italic' : 'text-white group-hover:text-blue-200'}`}>
                          {member.firstName} {member.lastName}
                        </p>
                        {member.accountStatus === 'Invited' && (
                          <span className="text-[10px] bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded border border-blue-500/30 font-bold uppercase">Invited</span>
                        )}
                      </div>
                      <p className="text-sm text-blue-100/60 truncate">{member.position}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end gap-1 pl-2">
                    {member.accountStatus === 'Invited' && isAdmin ? (
                      <button 
                        onClick={(e) => handleResendInvite(e, member)}
                        className="text-xs font-bold text-blue-300 hover:text-white underline decoration-blue-500/50 mb-1"
                      >
                        Resend
                      </button>
                    ) : (
                      member.duesPaid ? 
                        <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 tracking-wider">PAID</span> : 
                        <span className="text-xs font-bold text-red-400 bg-red-500/10 px-2 py-1 rounded border border-red-500/20 tracking-wider">UNPAID</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
            {isAdmin && (
              <div className="mt-4 pt-4 border-t border-white/10 text-center">
                <button onClick={downloadSampleCSV} className="text-sm font-bold text-blue-300 hover:text-white underline decoration-blue-500/50">Download CSV Roster</button>
              </div>
            )}
          </div>

          {/* COL 2: FINANCIAL OVERVIEW (MATCHES ROW HEIGHT) */}
          <div className="glass-panel p-6 flex flex-col h-full">
            <div className="flex items-center justify-between mb-6 h-[28px]">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                Financial Overview
              </h3>
            </div>
            
            <div className="flex-1 flex flex-col items-center justify-center -mt-6">
              <PieChart3D data={chartData} radius={110} depth={30} hole={0} />

              <div className="flex justify-center gap-12 w-full mt-2">
                <div className="flex flex-col items-center">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-4 h-4 rounded-full bg-red-600 shadow-[0_0_10px_rgba(220,38,38,0.8)]"></div>
                    <span className="text-lg font-bold text-white">Paid</span>
                  </div>
                  <span className="text-2xl font-mono text-white/90">{paidMembers}</span>
                </div>

                <div className="flex flex-col items-center">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-4 h-4 rounded-full bg-slate-400 shadow-[0_0_10px_rgba(148,163,184,0.5)]"></div>
                    <span className="text-lg font-bold text-white">Pending</span>
                  </div>
                  <span className="text-2xl font-mono text-white/90">{pendingDues}</span>
                </div>
              </div>
            </div>
          </div>

          {/* COL 3: QUICK ACTIONS */}
          <div className="glass-panel p-6 h-fit sticky top-24">
            <div className="flex items-center justify-between mb-6 h-[28px]">
              <h3 className="text-xl font-bold text-white">Quick Actions</h3>
            </div>
            <div className="space-y-2">
              {isAdmin && (
                <button onClick={() => setIsManageAdminsOpen(true)} className="w-full text-left p-3 rounded-xl bg-violet-600/20 border border-violet-500/30 hover:bg-violet-600/30 text-violet-100 transition-all flex items-center gap-3 group">
                  <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                  Manage Admins
                </button>
              )}
              <Link href="/announcements" className="w-full text-left p-3 rounded-xl bg-orange-500/20 border border-orange-500/30 hover:bg-orange-500/30 text-orange-100 transition-all flex items-center gap-3 group">
                <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" /></svg>
                Announcements
              </Link>
              <Link href="/documents" className="w-full text-left p-3 rounded-xl bg-teal-500/20 border border-teal-500/30 hover:bg-teal-500/30 text-teal-100 transition-all flex items-center gap-3 group">
                <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                Document Repository
              </Link>
              {isAdmin && (
                <>
                  <button onClick={handleOpenMemberCreate} className="w-full text-left p-3 rounded-xl bg-indigo-500/20 border border-indigo-500/30 hover:bg-indigo-500/30 text-indigo-100 transition-all flex items-center gap-3 group">
                    <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
                    Add New Member
                  </button>
                  <button onClick={handleExportAllMembers} className="w-full text-left p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/30 hover:bg-emerald-500/30 text-emerald-100 transition-all flex items-center gap-3 group">
                    <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                    Export Full Roster (CSV)
                  </button>
                  <button onClick={handleExportUnpaidMembers} className="w-full text-left p-3 rounded-xl bg-red-500/20 border border-red-500/30 hover:bg-red-500/30 text-red-100 transition-all flex items-center gap-3 group">
                    <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    Export Unpaid Members (CSV)
                  </button>
                  <div className="relative">
                    <input type="file" ref={csvInputRef} accept=".csv" onChange={handleFileUpload} className="hidden" />
                    <button onClick={() => csvInputRef.current?.click()} className="w-full text-left p-3 rounded-xl bg-blue-500/20 border border-blue-500/30 hover:bg-blue-500/30 text-blue-100 transition-all flex items-center gap-3 group">
                      <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                      Import Members
                    </button>
                  </div>
                  <button onClick={() => setIsEventModalOpen(true)} className="w-full text-left p-3 rounded-xl bg-purple-500/20 border border-purple-500/30 hover:bg-purple-500/30 text-purple-100 transition-all flex items-center gap-3 group">
                    <svg className="w-5 h-5 opacity-70 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    Create Event
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* --- MODALS --- */}
      {/* 1. MANAGE ADMINS MODAL (RESTORED) */}
      {isManageAdminsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm transition-opacity" onClick={() => setIsManageAdminsOpen(false)} />
          <div className="glass-panel w-full max-w-2xl p-8 relative animate-fade-in shadow-2xl border border-white/20 z-50 flex flex-col max-h-[80vh]">
            
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                <span className="w-3 h-3 rounded-full bg-violet-500 shadow-[0_0_15px_rgba(139,92,246,0.6)]"></span>
                Manage Administrators
              </h2>
              <button onClick={() => { setIsAddingAdmin(!isAddingAdmin); setAdminSearchTerm(''); }} className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${isAddingAdmin ? 'bg-slate-700 text-white rotate-45' : 'bg-violet-600 text-white hover:bg-violet-500'}`}>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
              {isAddingAdmin ? (
                <div className="space-y-4 animate-fade-in">
                  <input autoFocus type="text" placeholder="Search members to promote..." className="glass-input w-full" value={adminSearchTerm} onChange={(e) => setAdminSearchTerm(e.target.value)} />
                  {potentialAdmins.map(member => (
                    <div key={member.id} className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                      <div className="text-white font-bold">{member.firstName} {member.lastName} <span className="text-slate-400 font-normal">({member.email})</span></div>
                      <button onClick={() => handlePromoteToAdmin(member.id)} className="px-3 py-1 bg-violet-600 rounded text-xs font-bold hover:bg-violet-500 transition-colors">Promote</button>
                    </div>
                  ))}
                  {potentialAdmins.length === 0 && <div className="text-center text-white/30 py-4">No matching members found.</div>}
                </div>
              ) : (
                <div className="space-y-3 animate-fade-in">
                  {currentAdmins.map(admin => (
                    <div key={admin.id} className="flex justify-between items-center p-3 bg-violet-500/10 border border-violet-500/20 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-violet-600 flex items-center justify-center font-bold text-xs">{admin.firstName.charAt(0)}</div>
                        <div className="text-white font-bold">{admin.firstName} {admin.lastName}</div>
                      </div>
                      {admin.id !== currentUser.id && (
                        <button onClick={() => handleRevokeAdmin(admin.id)} className="text-red-400 hover:text-red-300 text-xs font-bold">Revoke</button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="mt-6 pt-4 border-t border-white/10 flex justify-end">
              <button onClick={() => setIsManageAdminsOpen(false)} className="px-6 py-2 text-white/60 hover:text-white transition-colors">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* 2. IMPORT PREVIEW MODAL */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm transition-opacity" onClick={() => setIsImportModalOpen(false)} />
          <div className="glass-panel w-full max-w-4xl p-8 relative animate-fade-in shadow-2xl border border-white/20 z-50 flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Review Import</h2>
              <span className="text-sm text-blue-200">Total Rows: {importPreviewData.length}</span>
            </div>
            <div className="flex-1 overflow-auto border border-white/10 rounded-xl bg-white/5 mb-6">
              <table className="w-full text-left text-sm text-white/80">
                <thead><tr className="border-b border-white/10 bg-white/5"><th className="p-3">First Name</th><th className="p-3">Last Name</th><th className="p-3">Email</th></tr></thead>
                <tbody>{importPreviewData.map(row => <tr key={row.id} className="border-b border-white/5"><td className="p-3">{row.firstName}</td><td className="p-3">{row.lastName}</td><td className="p-3">{row.email}</td></tr>)}</tbody>
              </table>
            </div>
            <div className="flex gap-4">
              <button onClick={() => setIsImportModalOpen(false)} className="flex-1 py-3 rounded-xl font-medium text-white/70 hover:bg-white/5">Cancel</button>
              <button onClick={confirmImport} className="flex-1 glass-button bg-emerald-500/20 hover:bg-emerald-500/30 text-white font-bold">Import Members</button>
            </div>
          </div>
        </div>
      )}

      {/* 3. MEMBER MODAL */}
      {isMemberModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm transition-opacity" onClick={() => setIsMemberModalOpen(false)} />
          <div className="glass-panel w-full max-w-2xl p-8 relative animate-fade-in shadow-2xl border border-white/20 max-h-[90vh] overflow-y-auto z-50">
            <h2 className="text-2xl font-bold text-white mb-6">{editingMemberId ? 'Edit Member' : 'Add Member'}</h2>
            <form onSubmit={handleMemberSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input required placeholder="First Name" className="glass-input" value={memberFormData.firstName} onChange={e => setMemberFormData({...memberFormData, firstName: e.target.value})} />
                <input required placeholder="Last Name" className="glass-input" value={memberFormData.lastName} onChange={e => setMemberFormData({...memberFormData, lastName: e.target.value})} />
              </div>
              <input required placeholder="Email" className="glass-input" value={memberFormData.email} onChange={e => setMemberFormData({...memberFormData, email: e.target.value})} />
              <input required placeholder="Position" className="glass-input" value={memberFormData.position} onChange={e => setMemberFormData({...memberFormData, position: e.target.value})} />
              <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                <span className="text-white">Dues Paid?</span>
                <Toggle checked={memberFormData.duesPaid} onChange={e => setMemberFormData({...memberFormData, duesPaid: e.target.checked})} labelOn="YES" labelOff="NO" color="emerald" />
              </div>
              <div className="flex gap-3 pt-4">
                {editingMemberId && <button type="button" onClick={handleDeleteMember} className="px-4 py-2 text-red-400 bg-red-500/10 rounded-lg">Delete</button>}
                <div className="flex-1 flex justify-end gap-3">
                  <button type="button" onClick={() => setIsMemberModalOpen(false)} className="px-4 py-2 text-white/60">Cancel</button>
                  <button type="submit" className="glass-button px-6 py-2">Save</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. EVENT MODAL (EXPANDED TO MATCH EVENTS PAGE) */}
      {isEventModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm transition-opacity" onClick={() => setIsEventModalOpen(false)} />
          <div className="glass-panel w-full max-w-lg p-8 relative animate-fade-in shadow-2xl border border-white/20 z-50">
            <h2 className="text-2xl font-bold text-white mb-6">Create Event</h2>
            <form onSubmit={handleEventSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Event Title</label>
                <input required placeholder="e.g. Annual Gala" className="glass-input w-full" value={eventFormData.title} onChange={e => setEventFormData({...eventFormData, title: e.target.value})} />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Date</label>
                  <input type="date" className="glass-input w-full" value={eventFormData.date} onChange={e => setEventFormData({...eventFormData, date: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Time</label>
                  <input type="time" className="glass-input w-full" value={eventFormData.time} onChange={e => setEventFormData({...eventFormData, time: e.target.value})} />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Category</label>
                <select className="glass-input w-full bg-slate-900" value={eventFormData.category} onChange={e => setEventFormData({...eventFormData, category: e.target.value})}>
                  <option value="Social">Social</option>
                  <option value="Meeting">Meeting</option>
                  <option value="Competition">Competition</option>
                  <option value="Fundraiser">Fundraiser</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Location</label>
                <input required placeholder="e.g. Grand Ballroom" className="glass-input w-full" value={eventFormData.location} onChange={e => setEventFormData({...eventFormData, location: e.target.value})} />
              </div>

              <div className="flex justify-end gap-3 pt-6">
                <button type="button" onClick={() => setIsEventModalOpen(false)} className="px-4 py-2 text-white/60 hover:text-white">Cancel</button>
                <button type="submit" className="glass-button px-6 py-2">Create Event</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </main>
  );
}

// --- HELPER COMPONENT (TOGGLE) ---
function Toggle({ checked, onChange, labelOn, labelOff, color = 'purple' }: { checked: boolean, onChange: (e: any) => void, labelOn?: string, labelOff?: string, color?: string }) {
  const colorClass = color === 'emerald' ? 'peer-checked:bg-emerald-500' : 'peer-checked:bg-purple-500';
  return (
    <label className="relative inline-flex items-center cursor-pointer">
      <input type="checkbox" className="sr-only peer" checked={checked} onChange={onChange} />
      <div className={`w-14 h-7 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all ${colorClass}`}></div>
      {labelOn && <span className="ml-3 text-sm font-bold text-white">{checked ? labelOn : labelOff}</span>}
    </label>
  );
}