export default function Home() {
  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden p-24">
      
      {/* 1. The Moving Background Orbs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="orb orb-1"></div>
        <div className="orb orb-2"></div>
        <div className="orb orb-3"></div>
      </div>

      {/* 2. The Glass Card */}
      <div className="glass-panel w-full max-w-md p-8 animate-fade-in z-10">
        <h1 className="text-3xl font-bold text-center mb-2 text-white">CrystalGrid</h1>
        <p className="text-center text-gray-300 mb-8">Member Access Portal</p>
        
        <form className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Email</label>
            <input type="email" className="glass-input" placeholder="you@example.com" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Password</label>
            <input type="password" className="glass-input" placeholder="••••••••" />
          </div>

          <button type="button" className="glass-button w-full text-white">
            Sign In
          </button>
        </form>
      </div>

    </main>
  );
}