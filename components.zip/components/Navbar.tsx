'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Navbar() {
  const pathname = usePathname();
  
  const isActive = (path: string) => pathname === path ? 'text-white bg-white/10 shadow-sm' : 'text-slate-400 hover:text-white hover:bg-white/5';

  return (
    <nav className="fixed top-6 left-0 right-0 z-50 flex justify-center px-4">
      <div className="glass-panel w-full max-w-6xl px-4 py-3 rounded-2xl flex items-center justify-between border border-white/10 bg-slate-900/60 backdrop-blur-xl shadow-2xl">
        
        {/* Logo */}
        <Link href="/dashboard" className="flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-700 flex items-center justify-center text-white font-bold text-lg shadow-lg group-hover:shadow-indigo-500/20 transition-all">
            C
          </div>
          <span className="font-bold text-lg tracking-tight text-white hidden md:block">CrystalGrid</span>
        </Link>

        {/* Navigation Links */}
        <div className="flex items-center gap-1 bg-white/5 rounded-xl p-1 border border-white/5">
          <Link href="/dashboard" className={`px-5 py-2 rounded-lg text-sm font-bold transition-all ${isActive('/dashboard')}`}>
            Dashboard
          </Link>
          <Link href="/directory" className={`px-5 py-2 rounded-lg text-sm font-bold transition-all ${isActive('/directory')}`}>
            Directory
          </Link>
          <Link href="/events" className={`px-5 py-2 rounded-lg text-sm font-bold transition-all ${isActive('/events')}`}>
            Events
          </Link>
        </div>

        {/* User Profile / Sign Out */}
        <div className="flex items-center gap-4">
          <div className="text-right hidden md:block">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Admin</div>
            <div className="text-sm font-bold text-white leading-none">Sarah Connor</div>
          </div>
          <button className="h-10 w-10 rounded-full bg-gradient-to-tr from-slate-700 to-slate-600 border border-white/10 hover:border-white/30 transition-all flex items-center justify-center group relative">
             <span className="font-bold text-sm text-white">SC</span>
             <div className="absolute inset-0 bg-red-500/80 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-[8px] font-bold uppercase tracking-tighter">Log Out</div>
          </button>
        </div>

      </div>
    </nav>
  );
}